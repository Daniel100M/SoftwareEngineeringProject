from flaskblog import app

if __name__ == '__main__':
    # app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres://db_project_9fv3_user:6aWLVrhvHaNESHX780JNRTo2N5Z98yIB@dpg-cnj0qned3nmc73fmsbf0-a.oregon-postgres.render.com/db_project_9fv3'
    app.run(debug=True)